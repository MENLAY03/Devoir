'Quel est le revenu du pepsi? '
QuantiteDeVente = 130
PrixPepsi = 1.50
Revenu = QuantiteDeVente * PrixPepsi
print(Revenu)

" Quel est le revenu du coca cola?"
QuantiteDeVente = 150
prixcocacola = 1.50
Revenu = QuantiteDeVente * prixcocacola
print(Revenu)


"Quel est le benefice du magasin?"
RevenuDuPepsi=195.0
RevenuDuCocacola=225.0
RevenuTotal = RevenuDuPepsi + RevenuDuCocacola
print(RevenuTotal)


"Quel est la marge du magasin?"
Benefice = 420.0
Depense = 2.500
Marge = Benefice / Depense
print(Marge)